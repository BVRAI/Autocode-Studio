// data.jsx — mock content for AutoCode Studio redesign

// Sessions live under the project they belong to (like the design sample).
const PROJECTS = [
  { id: "p_ac", name: "autocode gui", sessions: [
    { id: "s1", title: "Build C# desktop AutoCode app", time: "2h" },
    { id: "s2", title: "Fix WPF startup theme crash", time: "3h" },
    { id: "s3", title: "Port shell tool to C#", time: "1d" },
  ]},
  { id: "p_v8", name: "v8", sessions: [
    { id: "s4", title: "Plan Android app setup", time: "1mo" },
    { id: "s5", title: "are you there?", time: "1mo" },
  ]},
  { id: "p_v6", name: "v6", sessions: [
    { id: "s6", title: "Review latest Automax run fix", time: "2w" },
    { id: "s7", title: "Create AMV6 directory", time: "2w" },
    { id: "s8", title: "Caliper", time: "3w" },
  ]},
  { id: "p_eng", name: "engineer", sessions: [
    { id: "s9", title: "Review AutoMax v6 and v7 security", time: "3w" },
    { id: "s10", title: "Review AutoMax proxy security", time: "3w" },
  ]},
];

const MODES = {
  default:  { label: "Default",      icon: "shieldCheck", desc: "Edits & shell require approval" },
  autocode: { label: "Full access",  icon: "bolt",        desc: "Auto-approve file edits & shell" },
  planning: { label: "Plan only",    icon: "plan",        desc: "Read-only — no mutations" },
  admin:    { label: "Admin",        icon: "crown",       desc: "Unrestricted, incl. system ops" },
};

const PROVIDERS = {
  anthropic:  ["claude-sonnet-4.5", "claude-opus-4.1", "claude-haiku-4"],
  openai:     ["gpt-5.2", "gpt-5.2-mini", "o4"],
  xai:        ["grok-code-fast-1", "grok-4", "grok-4-mini"],
  openrouter: ["auto", "qwen3-coder", "deepseek-v3.2"],
};

// file tree (matches the workspace shown in current app)
const TREE = [
  { d: 0, t: "dir",  n: ".claude/" },
  { d: 1, t: "cfg",  n: "settings.local.json" },
  { d: 0, t: "dir",  n: ".github/" },
  { d: 1, t: "dir",  n: "workflows/" },
  { d: 2, t: "cfg",  n: "ci.yml" },
  { d: 2, t: "cfg",  n: "release.yml" },
  { d: 0, t: "dir",  n: "AutoCode.Desktop/" },
  { d: 1, t: "ts",   n: "App.xaml.cs" },
  { d: 1, t: "ts",   n: "MainWindow.xaml" },
  { d: 1, t: "ts",   n: "MainWindow.xaml.cs", mod: true },
  { d: 0, t: "dir",  n: "AutoCode.Engine/" },
  { d: 1, t: "dir",  n: "Agent/" },
  { d: 2, t: "ts",   n: "AgentLoop.cs" },
  { d: 2, t: "ts",   n: "PromptBuilder.cs" },
  { d: 1, t: "dir",  n: "Tools/" },
  { d: 2, t: "ts",   n: "FileTools.cs" },
  { d: 2, t: "ts",   n: "RunShellTool.cs" },
  { d: 2, t: "ts",   n: "SearchTools.cs" },
  { d: 1, t: "dir",  n: "Llm/" },
  { d: 0, t: "md",   n: "README.md" },
  { d: 0, t: "cfg",  n: "AutoCodeGui.sln" },
];

// initial tool timeline (completed run)
const TIMELINE_BASE = [
  { id: "t1", name: "read_file", dur: "0.1s", st: "done", sum: "App.xaml.cs · 1–60" },
  { id: "t2", name: "grep", dur: "0.3s", st: "done", sum: '"SetBrush" → 3 matches in MainWindow.xaml.cs' },
  { id: "t3", name: "read_file", dur: "0.1s", st: "done", sum: "MainWindow.xaml.cs · 560–600" },
  { id: "t4", name: "edit_file", dur: "0.2s", st: "done", sum: "MainWindow.xaml.cs +1 −8" },
  { id: "t5", name: "edit_file", dur: "0.2s", st: "done", sum: "App.xaml.cs +41 −12" },
  { id: "t6", name: "run_shell", dur: "11.4s", st: "done", sum: "dotnet build → Build succeeded" },
  { id: "t7", name: "run_shell", dur: "6.2s", st: "done", sum: "dotnet test → Passed 5/5" },
];

window.ACDATA = { PROJECTS, MODES, PROVIDERS, TREE, TIMELINE_BASE };
