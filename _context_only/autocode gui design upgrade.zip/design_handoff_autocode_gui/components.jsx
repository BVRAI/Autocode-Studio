// components.jsx — shell: titlebar, sidebar, side panel, menus
const { useState: useStateC } = React;
const IconC = window.Icon;

function TitleBar() {
  return (
    <div className="titlebar">
      <div className="tb-brand">
        <span className="tb-logo"><IconC name="bolt" size={11} /></span>
        AutoCode Studio
      </div>
      <div className="tb-spacer" />
      <div className="win-controls">
        <button className="win-btn"><IconC name="min" size={16} stroke={1.6} /></button>
        <button className="win-btn"><IconC name="max" size={13} stroke={1.6} /></button>
        <button className="win-btn close"><IconC name="x" size={16} stroke={1.6} /></button>
      </div>
    </div>
  );
}

function Sidebar({ collapsed, projects, activeId, onSelect, onNew, usage, onSettings, settingsRef }) {
  const [open, setOpen] = useStateC({ p_ac: true });
  const toggle = (id) => setOpen((o) => ({ ...o, [id]: !o[id] }));
  return (
    <div className={"sidebar" + (collapsed ? " collapsed" : "")}>
      <div className="sb-top">
        <button className="sb-newbtn" onClick={onNew}><IconC name="plus" size={16} /> New session</button>
        <button className="sb-item"><IconC name="search" size={16} /> Search</button>
      </div>
      <div className="sb-scroll">
        <div className="sb-section">Projects</div>
        {projects.map((p) => (
          <div key={p.id}>
            <button className="sb-project" onClick={() => toggle(p.id)}>
              <IconC name="chevR" size={13} className="pchev" style={{ transform: open[p.id] ? "rotate(90deg)" : "none" }} />
              <IconC name="folder" size={14} style={{ color: "var(--accent)" }} />
              <span className="pname">{p.name}</span>
            </button>
            {open[p.id] && p.sessions.map((s) => (
              <button key={s.id} className={"sb-session nested" + (s.id === activeId ? " active" : "")} onClick={() => onSelect(s.id)}>
                <span className="title">{s.title}</span>
                {s.id === activeId ? <span className="dot" /> : <span className="time">{s.time}</span>}
              </button>
            ))}
          </div>
        ))}
        <div className="sb-section">Chats</div>
        <div style={{ padding: "2px 11px 6px", color: "var(--text-faint)", fontSize: 12.5 }}>No chats</div>
      </div>
      <div className="sb-foot">
        <div className="usage-card">
          <div className="usage-head">
            <span className="lbl">Context</span>
            <span className="val">{usage.pct}% used</span>
          </div>
          <div className="usage-bar"><span style={{ width: usage.pct + "%" }} /></div>
          <div className="usage-sub">
            <span>in <b>{usage.in}</b></span>
            <span>out <b>{usage.out}</b></span>
          </div>
        </div>
        <button className="sb-item" ref={settingsRef} onClick={onSettings}><IconC name="settings" size={16} /> Settings</button>
      </div>
    </div>
  );
}

function Modal({ title, subtitle, children, onClose, footer, width = 460 }) {
  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal" style={{ width }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <div className="modal-title">{title}</div>
            {subtitle && <div className="modal-sub">{subtitle}</div>}
          </div>
          <button className="iconbtn" onClick={onClose}><IconC name="x" size={17} /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

function Tree({ rows }) {
  return (
    <div className="tree">
      {rows.map((r, i) => (
        <div className={"row" + (r.t === "dir" ? " dir" : "")} key={i} style={{ paddingLeft: 6 + r.d * 16 }}>
          <IconC name={r.t === "dir" ? "folder" : "file"} size={14} className={r.t} />
          <span>{r.n}</span>
          {r.mod && <span style={{ marginLeft: "auto", color: "var(--amber)", fontSize: 11 }}>M</span>}
        </div>
      ))}
    </div>
  );
}

function StatusDot({ st }) {
  if (st === "run") return <span className="st run"><IconC name="spinner" size={12} className="spin" /></span>;
  if (st === "err") return <span className="st err"><IconC name="x" size={11} stroke={2.2} /></span>;
  return <span className="st done"><IconC name="check" size={11} stroke={2.4} /></span>;
}

function ApprovalCard({ req, onDecide }) {
  const [rev, setRev] = React.useState("");
  return (
    <div className="approval">
      <div className="ap-head"><IconC name="alert" size={16} /> Pending approval</div>
      <div className="ap-tool"><b>{req.tool}</b> · {req.target}</div>
      <div className="ap-preview">
        {req.preview.map((l, i) => (
          <div key={i} className={l[0] === "+" ? "pl-add" : l[0] === "-" ? "pl-del" : "pl-ctx"}>{l}</div>
        ))}
      </div>
      <textarea className="ap-revision" rows={2} placeholder="Optional revision guidance…" value={rev} onChange={(e) => setRev(e.target.value)} />
      <div className="ap-actions">
        <button className="btn danger" onClick={() => onDecide("declined")}>Decline</button>
        <button className="btn" onClick={() => onDecide("revised")}>Revise</button>
        <button className="btn primary" onClick={() => onDecide("approved")}>Accept</button>
      </div>
    </div>
  );
}

function SidePanel({ open, tab, onTab, onClose, sessionMeta, tree, timeline, approval, onDecide, approvalState }) {
  return (
    <div className={"sidepanel" + (open ? " open" : "")}>
      <div className="sp-head">
        <div className="sp-tabs">
          <button className={"sp-tab" + (tab === "workspace" ? " active" : "")} onClick={() => onTab("workspace")}>
            <IconC name="folder" size={14} /> Workspace
          </button>
          <button className={"sp-tab" + (tab === "run" ? " active" : "")} onClick={() => onTab("run")}>
            <IconC name="terminal" size={14} /> Run {approval && approvalState === "pending" && <span className="badge" />}
          </button>
        </div>
        <div style={{ flex: 1 }} />
        <button className="iconbtn" onClick={onClose} title="Close panel"><IconC name="x" size={16} /></button>
      </div>
      <div className="sp-body">
        {tab === "workspace" ? (
          <React.Fragment>
            <div className="sp-block">
              <div className="sp-label">Session</div>
              <div className="sess-meta">
                <div><span className="k">id</span> &nbsp;{sessionMeta.id}</div>
                <div><span className="k">model</span> &nbsp;{sessionMeta.model}</div>
                <div><span className="k">root</span> &nbsp;…\automax\autocode</div>
              </div>
            </div>
            <div className="sp-block">
              <div className="sp-label">Files</div>
              <Tree rows={tree} />
            </div>
          </React.Fragment>
        ) : (
          <React.Fragment>
            {approval && approvalState === "pending" && <ApprovalCard req={approval} onDecide={onDecide} />}
            {approval && approvalState !== "pending" && (() => {
              const map = {
                approved: { cls: "ok", ic: "check", txt: "Approved — " + approval.tool + " applied" },
                "auto":   { cls: "ok", ic: "bolt", txt: "Auto-approved — " + approval.tool + " applied" },
                declined: { cls: "no", ic: "x", txt: "Declined — change skipped" },
                revised:  { cls: "", ic: "undo", txt: "Revision requested" },
                blocked:  { cls: "no", ic: "shield", txt: "Blocked — read-only (plan) mode" },
              }[approvalState] || { cls: "", ic: "undo", txt: "" };
              return (
                <div className={"resolved " + map.cls} style={{ marginBottom: 14 }}>
                  <IconC name={map.ic} size={15} /> {map.txt}
                </div>
              );
            })()}
            <div className="sp-label">Tool timeline</div>
            <div className="timeline" style={{ marginTop: 8 }}>
              {timeline.length === 0 && <div className="empty-tl">No tools run yet.</div>}
              {timeline.map((t) => (
                <div className="tl-item" key={t.id}>
                  <div className="tl-top">
                    <StatusDot st={t.st} />
                    <span className="tl-name">{t.name}</span>
                    <span className="grow" />
                    <span className="tl-dur">{t.dur}</span>
                  </div>
                  {t.sum && <div className="tl-sum">{t.sum}</div>}
                </div>
              ))}
            </div>
          </React.Fragment>
        )}
      </div>
    </div>
  );
}

function Menu({ pos, children, onClose }) {
  React.useEffect(() => {
    const h = () => onClose();
    window.addEventListener("resize", h);
    return () => window.removeEventListener("resize", h);
  }, []);
  return (
    <React.Fragment>
      <div className="scrim" onClick={onClose} />
      <div className="menu" style={pos} onClick={(e) => e.stopPropagation()}>{children}</div>
    </React.Fragment>
  );
}

Object.assign(window, { TitleBar, Sidebar, Tree, SidePanel, ApprovalCard, Menu, StatusDot, Modal });
