// conversation.jsx — transcript blocks + composer
const { useState } = React;
const Icon = window.Icon;

function WorkedGroup({ label, steps, defaultOpen }) {
  const [open, setOpen] = useState(!!defaultOpen);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: open ? 12 : 0 }}>
      <button className={"worked" + (open ? " open" : "")} onClick={() => setOpen(!open)}>
        <Icon name="chevR" size={15} className="chev" />
        <Icon name="bolt" size={14} className="spark" />
        <span>{label}</span>
      </button>
      {open && (
        <div className="substeps">
          {steps.map((s, i) => (
            <div className="substep" key={i}>
              <Icon name="check" size={13} className="ticon" style={{ color: "var(--green)" }} />
              <span><span className="tn">{s.name}</span> &nbsp;{s.detail}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function DiffCard({ title, add, del, files, onReview }) {
  return (
    <div className="diffcard">
      <div className="dc-head">
        <div className="dc-ico"><Icon name="diff" size={17} /></div>
        <div>
          <div className="dc-title">{title}</div>
          <div className="dc-counts"><span className="add">+{add}</span> <span className="del">−{del}</span></div>
        </div>
        <div className="grow" />
        <div className="dc-actions">
          <button className="ghost-btn"><Icon name="undo" size={14} /> Undo</button>
          <button className="ghost-btn" onClick={onReview}>Review</button>
        </div>
      </div>
      <div className="dc-files">
        {files.map((f, i) => (
          <div className="dc-file" key={i}>
            <Icon name="file" size={14} style={{ color: "var(--text-faint)" }} />
            <span className="fn">{f.name}</span>
            <span className="fc"><span className="add">+{f.add}</span> <span className="del">−{f.del}</span></span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Reactions() {
  return (
    <div className="reactions">
      <button className="react-btn" title="Copy"><Icon name="copy" size={15} /></button>
      <button className="react-btn" title="Good"><Icon name="thumbUp" size={15} /></button>
      <button className="react-btn" title="Bad"><Icon name="thumbDn" size={15} /></button>
      <button className="react-btn" title="Share"><Icon name="share" size={15} /></button>
    </div>
  );
}

// The static base transcript
function BaseTranscript({ onReview }) {
  return (
    <React.Fragment>
      <WorkedGroup label="Worked for 12s" steps={[
        { name: "read_file", detail: "App.xaml.cs" },
        { name: "run_shell", detail: "start AutoCode.Desktop" },
      ]} />
      <div className="msg-assistant">
        <p>Restarted. AutoCode Studio is running; main window process is PID <code>21864</code>.</p>
      </div>

      <div className="bubble-row">
        <div className="bubble">It seemed like it just crashed or something. I'm not sure exactly what happened. I didn't close it that time — it just opened up and closed. Is there a crash log or anything like that?</div>
      </div>

      <WorkedGroup label="Worked for 4m 1s" defaultOpen steps={[
        { name: "grep", detail: '"SetBrush" → MainWindow.xaml.cs' },
        { name: "read_file", detail: "MainWindow.xaml.cs · 560–600" },
        { name: "edit_file", detail: "MainWindow.xaml.cs" },
        { name: "edit_file", detail: "App.xaml.cs" },
        { name: "run_shell", detail: "dotnet build · dotnet test" },
      ]} />

      <div className="msg-assistant">
        <p>Yes. Windows Event Viewer had <code>.NET Runtime</code> crash entries from the earlier launches. The cause was a WPF startup theme crash: <code>SetBrush</code> was trying to modify a read-only / frozen brush resource.</p>
        <p>I fixed it in <a className="fileref" href="#"><Icon name="code" size={13} />MainWindow.xaml.cs (line 578)</a> by replacing the brush resource instead of mutating it. I also added an app crash logger in <a className="fileref" href="#"><Icon name="code" size={13} />App.xaml.cs (line 1)</a>; future app crashes will write to:</p>
        <div className="pathblock">%LOCALAPPDATA%\autocode-gui\crash.log</div>
        <p style={{ marginTop: 12 }}>Validation: <code>dotnet build</code> succeeds, <code>dotnet test</code> passes 5/5, and the app is currently running as <code>AutoCode Studio</code> with PID <code>33332</code>. No new crash log exists yet because the latest launch did not crash.</p>
      </div>

      <DiffCard title="Edited 2 files" add={42} del={20} onReview={onReview} files={[
        { name: "AutoCode.Desktop/App.xaml.cs", add: 41, del: 12 },
        { name: "AutoCode.Desktop/MainWindow.xaml.cs", add: 1, del: 8 },
      ]} />

      <Reactions />
    </React.Fragment>
  );
}

function Composer({ mode, modeInfo, provider, model, onSend, onModeClick, onModelClick, status }) {
  const [val, setVal] = useState("");
  const ta = React.useRef(null);
  const grow = (el) => { if (!el) return; el.style.height = "auto"; el.style.height = Math.min(el.scrollHeight, 160) + "px"; };
  const submit = () => { const v = val.trim(); if (!v) return; onSend(v); setVal(""); if (ta.current) ta.current.style.height = "auto"; };
  const busy = status === "working";
  return (
    <div className="composer-wrap">
      <div className="composer">
        <textarea
          ref={ta}
          rows={1}
          placeholder="Ask for follow-up changes"
          value={val}
          onChange={(e) => { setVal(e.target.value); grow(e.target); }}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } }}
        />
        <div className="composer-bar">
          <button className="cbtn" title="Attach"><Icon name="plus" size={18} /></button>
          <button className={"pill mode-" + mode} onClick={onModeClick} title={modeInfo.desc}>
            <Icon name={modeInfo.icon} size={15} />
            {modeInfo.label}
            <Icon name="chevD" size={13} />
          </button>
          <button className="pill" onClick={onModelClick}>
            <Icon name="cube" size={14} />
            {provider} · {model}
            <Icon name="chevD" size={13} />
          </button>
          <div className="grow" />
          <button className="cbtn" title="Dictate"><Icon name="mic" size={17} /></button>
          {busy
            ? <button className="send-btn" title="Stop" onClick={() => onSend(null)} style={{ background: "var(--text)" }}><Icon name="stop" size={15} /></button>
            : <button className="send-btn" title="Send" disabled={!val.trim()} onClick={submit}><Icon name="arrowUp" size={17} /></button>}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { WorkedGroup, DiffCard, Reactions, BaseTranscript, Composer });
