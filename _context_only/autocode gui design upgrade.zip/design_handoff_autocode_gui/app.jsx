// app.jsx — AutoCode Studio redesign, main composition
const { useState: uS, useEffect: uE, useRef: uR } = React;
const I = window.Icon;
const D = window.ACDATA;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#2f6fe0",
  "dark": false,
  "density": "regular",
  "uiFont": "Geist"
}/*EDITMODE-END*/;

const DENSITY = { compact: { pad: 0.82, fs: "13px" }, regular: { pad: 1, fs: "14px" }, comfy: { pad: 1.16, fs: "15px" } };
const FONTS = { Geist: '"Geist", -apple-system, "Segoe UI", system-ui, sans-serif', System: '-apple-system, "Segoe UI", Roboto, system-ui, sans-serif' };

const APPROVAL = {
  tool: "edit_file",
  target: "AutoCode.Desktop/App.xaml.cs · line 42",
  preview: [
    "  protected override void OnStartup(StartupEventArgs e)",
    "  {",
    "-     // TODO: wire global crash handler",
    "+     AppDomain.CurrentDomain.UnhandledException += LogCrash;",
    "+     DispatcherUnhandledException += (s, ex) => LogCrash(ex.Exception);",
    "      base.OnStartup(e);",
    "  }",
  ],
};

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [collapsed, setCollapsed] = uS(false);
  const [panelOpen, setPanelOpen] = uS(true);
  const [tab, setTab] = uS("run");
  const [mode, setMode] = uS("default");
  const [provider, setProvider] = uS("xai");
  const [model, setModel] = uS("grok-code-fast-1");
  const [activeId, setActiveId] = uS("s1");
  const [menu, setMenu] = uS(null); // {type, pos}
  const [modal, setModal] = uS(null); // "byok" | "proxy" | "about"
  const settingsRef = uR(null);
  const [timeline, setTimeline] = uS(D.TIMELINE_BASE);
  const [decision, setDecision] = uS("pending"); // user's explicit decision
  const [extra, setExtra] = uS([]); // appended messages
  const [status, setStatus] = uS("ready");
  const chatRef = uR(null);

  // derived approval state from mode + decision
  const derived = (() => {
    if (decision !== "pending") return decision;
    if (mode === "autocode" || mode === "admin") return "auto";
    if (mode === "planning") return "blocked";
    return "pending";
  })();
  const pendingNow = derived === "pending";

  // apply tweaks
  uE(() => {
    const r = document.documentElement;
    r.style.setProperty("--accent", t.accent);
    r.setAttribute("data-theme", t.dark ? "dark" : "light");
    const d = DENSITY[t.density] || DENSITY.regular;
    r.style.setProperty("--pad", d.pad);
    r.style.setProperty("--fs", d.fs);
    r.style.setProperty("--ui-font", FONTS[t.uiFont] || FONTS.Geist);
  }, [t]);

  uE(() => { if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight; }, [extra, status]);

  const modeInfo = D.MODES[mode];
  const openPanel = (which) => { setTab(which); setPanelOpen(true); };

  const onDecide = (kind) => {
    setDecision(kind);
    if (kind === "approved") {
      setTimeline((tl) => [...tl, { id: "ta" + Date.now(), name: "edit_file", dur: "0.2s", st: "done", sum: "App.xaml.cs +2 −1 · approved" }]);
    }
  };

  const sendMsg = (text) => {
    if (text === null) { setStatus("ready"); return; } // stop
    setExtra((e) => [...e, { role: "user", text }]);
    setStatus("working");
    setTimeline((tl) => [...tl, { id: "tr" + Date.now(), name: "grep", dur: "…", st: "run", sum: "scanning workspace…" }]);
    setTimeout(() => {
      setTimeline((tl) => tl.map((x) => x.st === "run" ? { ...x, st: "done", dur: "0.4s", sum: "scanned 38 files" } : x));
      setExtra((e) => [...e, { role: "assistant", text: "Done — scanned the workspace and applied your follow-up. Build is green and the app is still running as AutoCode Studio." }]);
      setStatus("ready");
    }, 1600);
  };

  const openMenu = (type, e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = { left: rect.left, bottom: window.innerHeight - rect.top + 8 };
    setMenu({ type, pos });
  };

  const sessionMeta = { id: "20260602-215440-51bc36", model: provider + "/" + model };
  const usage = { pct: 31, in: "48.1k", out: "9.7k" };

  return (
    <div className="desktop">
      <div className="window">
        <TitleBar />
        <div className="body">
          <Sidebar
            collapsed={collapsed}
            projects={D.PROJECTS}
            activeId={activeId}
            onSelect={setActiveId}
            onNew={() => { setExtra([]); setDecision("pending"); setStatus("ready"); }}
            usage={usage}
            settingsRef={settingsRef}
            onSettings={() => {
              const r = settingsRef.current.getBoundingClientRect();
              setMenu({ type: "settings", pos: { left: r.left, bottom: window.innerHeight - r.top + 8 } });
            }}
          />

          <div className="main">
            <div className="topbar">
              <button className="iconbtn" title="Toggle sidebar" onClick={() => setCollapsed(!collapsed)}><I name="menu" size={18} /></button>
              <div className="chat-title">
                Build C# desktop AutoCode app
                <span className="sub">· edited 2h ago</span>
              </div>
              <div className="grow" />
              <div className="path-chip" title="C:\Users\Gregory\Desktop\automax\autocode">
                <I name="folder" size={13} style={{ color: "var(--text-3)" }} />
                <span className="p">…\automax\autocode</span>
              </div>
              <button className="iconbtn" title={t.dark ? "Switch to light" : "Switch to dark"} onClick={() => setTweak("dark", !t.dark)}>
                <I name={t.dark ? "sun" : "moon"} size={18} />
              </button>
              <button className={"iconbtn" + (panelOpen && tab === "workspace" ? " on" : "")} title="Workspace" onClick={() => openPanel("workspace")}><I name="panel" size={18} /></button>
              <button className={"iconbtn" + (panelOpen && tab === "run" ? " on" : "")} title="Run" onClick={() => openPanel("run")}>
                <I name="terminal" size={18} />
                {pendingNow && !panelOpen && <span className="badge" />}
              </button>
              <button className="iconbtn" title="Session menu"><I name="dots" size={18} /></button>
            </div>

            <div className="chat" ref={chatRef}>
              <div className="chat-inner">
                <BaseTranscript onReview={() => openPanel("run")} />
                {extra.map((m, i) => (
                  m.role === "user"
                    ? <div className="bubble-row" key={i}><div className="bubble">{m.text}</div></div>
                    : <div className="msg-assistant" key={i}><p>{m.text}</p></div>
                ))}
                {status === "working" && (
                  <button className="worked open" style={{ cursor: "default" }}>
                    <I name="spinner" size={14} className="spin spark" />
                    <span>Working…</span>
                  </button>
                )}
              </div>
            </div>

            <Composer
              mode={mode} modeInfo={modeInfo} provider={provider} model={model}
              status={status}
              onSend={sendMsg}
              onModeClick={(e) => openMenu("mode", e)}
              onModelClick={(e) => openMenu("model", e)}
            />
          </div>

          <SidePanel
            open={panelOpen} tab={tab} onTab={setTab} onClose={() => setPanelOpen(false)}
            sessionMeta={sessionMeta} tree={D.TREE} timeline={timeline}
            approval={APPROVAL} approvalState={derived} onDecide={onDecide}
          />
        </div>
      </div>

      {menu && menu.type === "mode" && (
        <Menu pos={menu.pos} onClose={() => setMenu(null)}>
          <div className="menu-label">Mode</div>
          {Object.entries(D.MODES).map(([k, v]) => (
            <button key={k} className={"menu-item" + (k === mode ? " sel" : "")} onClick={() => { setMode(k); setMenu(null); }}>
              <I name={v.icon} size={16} />
              <span style={{ flex: 1 }}>
                <div>{v.label}</div>
                <div className="mi-sub">{v.desc}</div>
              </span>
              {k === mode && <I name="check" size={15} />}
            </button>
          ))}
        </Menu>
      )}

      {menu && menu.type === "model" && (
        <Menu pos={menu.pos} onClose={() => setMenu(null)}>
          <div className="menu-label">Provider</div>
          {Object.keys(D.PROVIDERS).map((p) => (
            <button key={p} className={"menu-item" + (p === provider ? " sel" : "")} onClick={() => { setProvider(p); setModel(D.PROVIDERS[p][0]); }}>
              <I name="cube" size={15} /><span style={{ flex: 1 }}>{p}</span>{p === provider && <I name="check" size={15} />}
            </button>
          ))}
          <div className="menu-sep" />
          <div className="menu-label">Model · {provider}</div>
          {D.PROVIDERS[provider].map((m) => (
            <button key={m} className={"menu-item" + (m === model ? " sel" : "")} onClick={() => { setModel(m); setMenu(null); }}>
              <span style={{ flex: 1, fontFamily: "var(--mono-font)", fontSize: 12.5 }}>{m}</span>{m === model && <I name="check" size={15} />}
            </button>
          ))}
        </Menu>
      )}

      {menu && menu.type === "settings" && (
        <Menu pos={menu.pos} onClose={() => setMenu(null)}>
          <button className="menu-item" onClick={() => { setMenu(null); setModal("byok"); }}>
            <I name="key" size={16} /><span style={{ flex: 1 }}>Bring your own keys</span>
          </button>
          <button className="menu-item" onClick={() => { setMenu(null); setModal("proxy"); }}>
            <I name="link" size={16} /><span style={{ flex: 1 }}>Proxy access</span>
          </button>
          <div className="menu-sep" />
          <button className="menu-item" onClick={() => { setTweak("dark", !t.dark); setMenu(null); }}>
            <I name={t.dark ? "sun" : "moon"} size={16} /><span style={{ flex: 1 }}>{t.dark ? "Light mode" : "Dark mode"}</span>
          </button>
          <button className="menu-item" onClick={() => { setMenu(null); setModal("about"); }}>
            <I name="bolt" size={16} /><span style={{ flex: 1 }}>About AutoCode Studio</span>
          </button>
        </Menu>
      )}

      {modal === "byok" && (
        <Modal title="Bring your own keys" subtitle="Environment variables take precedence. Saved keys are written to ~/.autocode-gui/config.json."
          onClose={() => setModal(null)} width={500}
          footer={<React.Fragment>
            <button className="btn" onClick={() => setModal(null)}>Cancel</button>
            <button className="btn primary" onClick={() => setModal(null)}>Save keys</button>
          </React.Fragment>}>
          {[
            ["Anthropic", "ANTHROPIC_API_KEY", "sk-ant-…"],
            ["OpenAI", "OPENAI_API_KEY", "sk-…"],
            ["xAI", "XAI_API_KEY", "xai-…"],
            ["OpenRouter", "OPENROUTER_API_KEY", "sk-or-…"],
            ["Brave Search", "BRAVE_API_KEY", "BSA…"],
          ].map(([label, env, ph]) => (
            <div className="field" key={env}>
              <label>{label} <span className="env">{env}</span></label>
              <input type="password" placeholder={ph} defaultValue={label === "xAI" ? "xai-7f3c••••••••••••••••" : ""} />
            </div>
          ))}
        </Modal>
      )}

      {modal === "proxy" && (
        <Modal title="Proxy access" subtitle="Route provider requests through a configurable proxy. Falls back to AUTOCODE_GUI_PROXY_* env vars."
          onClose={() => setModal(null)} width={500}
          footer={<React.Fragment>
            <button className="btn" onClick={() => setModal(null)}>Cancel</button>
            <button className="btn primary" onClick={() => setModal(null)}>Save</button>
          </React.Fragment>}>
          <div className="field">
            <label>Proxy URL <span className="env">AUTOCODE_GUI_PROXY_URL</span></label>
            <input type="text" placeholder="https://your-proxy.example.com" defaultValue="https://proxy.automax.dev" />
          </div>
          <div className="field">
            <label>Proxy token <span className="env">AUTOCODE_GUI_PROXY_TOKEN</span></label>
            <input type="password" placeholder="token" defaultValue="amx_live_••••••••••••" />
          </div>
          <div className="field-note">Requests route to <code>{"{proxyBaseUrl}/v1/{provider}"}</code> — e.g. <code>/v1/anthropic/messages</code>.</div>
        </Modal>
      )}

      {modal === "about" && (
        <Modal title="AutoCode Studio" subtitle="Automax agentic code shell"
          onClose={() => setModal(null)} width={420}
          footer={<button className="btn primary" onClick={() => setModal(null)}>Close</button>}>
          <div className="field-note" style={{ marginTop: 0 }}>
            A self-contained C#/.NET 8 desktop port of the AutoCode agent runtime. Provider-neutral tool loop, project-scoped tools, approvals, sessions, and BYOK credentials.
          </div>
          <div className="sess-meta" style={{ marginTop: 14 }}>
            <div><span className="k">version</span> &nbsp;0.4.0</div>
            <div><span className="k">engine</span> &nbsp;AutoCode.Engine</div>
            <div><span className="k">runtime</span> &nbsp;.NET 8 · WPF</div>
          </div>
        </Modal>
      )}

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakColor label="Accent" value={t.accent}
          options={["#2f6fe0", "#6d54e0", "#1f8a5b", "#d97757"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Layout" />
        <TweakRadio label="Density" value={t.density} options={["compact", "regular", "comfy"]} onChange={(v) => setTweak("density", v)} />
        <TweakRadio label="UI font" value={t.uiFont} options={["Geist", "System"]} onChange={(v) => setTweak("uiFont", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
