# Handoff: AutoCode Studio — GUI Redesign

## Overview
This package documents a high-fidelity redesign of **AutoCode Studio** — a native C#/.NET 8 WPF desktop app that is a self-contained port of the AutoCode agent runtime (agentic tool loop, project-scoped file tools, command-safety approvals, sessions, BYOK credentials, configurable proxy).

The redesign takes the app from a plain, utilitarian WPF layout to a calm, polished, generously-spaced UI inspired by modern agentic-chat clients. The goal of this handoff is to reproduce that redesign **inside the existing WPF app** (XAML + C#), keeping all current functionality and wiring.

## About the Design Files
The files in this bundle (`AutoCode Studio.html`, `styles.css`, and the `.jsx` files) are **design references created in HTML/React** — an interactive prototype that demonstrates the intended look, layout, and behavior. **They are not production code to copy directly.**

The task is to **recreate this design in the existing AutoCode Studio codebase** — i.e. rebuild `MainWindow.xaml` / `App.xaml` (and supporting styles, resource dictionaries, value converters, view-models) so the native WPF app matches the prototype. Use WPF-native patterns (Styles, ControlTemplates, DynamicResource theming, DataTemplates, ItemsControl/ListBox) — do **not** embed a web view. The React/CSS here only exists to communicate intent.

The current app source for reference lives in the repo:
- `AutoCode.Desktop/MainWindow.xaml` + `MainWindow.xaml.cs` (the screen being redesigned)
- `AutoCode.Desktop/App.xaml` + `App.xaml.cs`
- `AutoCode.Engine/*` (unchanged — the engine, tools, modes, providers)

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, and interaction states are specified below and should be reproduced faithfully. Where this document gives an exact hex/px value, use it. The one substitution to make: the prototype uses the **Geist** / **Geist Mono** webfonts; in the native app use **Segoe UI Variable / Segoe UI** for UI text and **Cascadia Code / Cascadia Mono** for monospace (the closest native Windows equivalents), keeping the same sizes/weights.

---

## Layout (top-level structure)
A single resizable window (default **1320 × 840**, min **1080 × 720**), composed top-to-bottom:

```
┌───────────────────────────────────────────────────────────────┐
│ Title bar (38px)  — app icon + "AutoCode Studio" · window ctls │
├──────────┬──────────────────────────────────┬─────────────────┤
│ Sidebar  │  Main column                     │  Side panel     │
│ 262px    │  (flex, fills remaining width)   │  0 / 372px      │
│          │                                  │  (collapsible)  │
│ • new    │  • Top bar (52px)                │  Tabs:          │
│ • search │  • Conversation (scroll)         │   Workspace|Run │
│ • proj   │  • Composer                      │                 │
│   tree   │                                  │  (slide-over)   │
│ • usage  │                                  │                 │
│ • settin │                                  │                 │
└──────────┴──────────────────────────────────┴─────────────────┘
```

The window itself sits on the desktop with a 14px corner radius and a large soft drop shadow (this is just for the prototype frame — in the real app it's a normal OS window; you may keep the native window chrome OR a custom chrome titlebar matching the design — see "Title bar").

### Theming
The app supports **light** (default) and **dark** themes, swapped at runtime. In WPF, implement as two `ResourceDictionary` sets of `SolidColorBrush` keys (the current app already uses `DynamicResource` brush keys — extend that). Every color below is given for both themes in **Design Tokens**.

---

## Screens / Views

### 1. Title bar
- **Height** 38px. Background `--titlebar`. Bottom 1px border `--border`.
- **Left**: 12px left padding → a 17×17 rounded-5px logo chip (gradient `135deg, accent → violet #7a5ae0`, white bolt glyph) + "AutoCode Studio" at 12.5px / weight 500, color `--titlebar-text`.
- **Right**: window controls — three 46px-wide full-height buttons: minimize, maximize, close. Hover = `--hover-strong`; **close** hover = `#e5443b` bg, white glyph.
- If using native WPF chrome instead, surface app title + the brand chip in the top bar instead.

### 2. Sidebar (left, 262px)
Background `--surface-2`, right border 1px `--border`. Collapsible to width 0 (animate width/opacity ~0.22s). Three regions:

**Top (padding 12px):**
- **New session** button: full width, 10px radius, 1px border `--border-strong`, bg `--surface`, subtle shadow, `+` icon + "New session" (13.5px / 500). Hover bg `--surface-3`.
- **Search** row: ghost item, search icon + "Search" (13.5px), color `--text-2`. Hover bg `--hover`.

**Scroll region (Projects):**
- Section label "PROJECTS" — 11px, uppercase, letter-spacing .04em, weight 600, color `--text-faint`, padding 14/11/6.
- **Sessions are grouped under their project.** Each project is a collapsible row:
  - Project header: chevron (rotates 90° when open) + folder icon (color `--accent`) + project name (13px / 500, color `--text`). Hover bg `--hover`.
  - When expanded, its sessions render indented (padding-left 30px) as session rows: title (13px, ellipsis) + either a relative time (`--text-faint`, e.g. "3h", "2w", "1mo") OR, for the active session, a 6px accent dot.
  - Active session row: bg `--surface-4`, text `--text`.
- Sample data used in the prototype (replace with real sessions/projects from `%LocalAppData%\autocode-gui\sessions`):
  - **autocode gui** (expanded): "Build C# desktop AutoCode app" (active), "Fix WPF startup theme crash" (3h), "Port shell tool to C#" (1d)
  - **v8**: "Plan Android app setup" (1mo), "are you there?" (1mo)
  - **v6**: "Review latest Automax run fix" (2w), "Create AMV6 directory" (2w), "Caliper" (3w)
  - **engineer**: "Review AutoMax v6 and v7 security" (3w), "Review AutoMax proxy security" (3w)
- Section label "CHATS" → "No chats" placeholder (`--text-faint`, 12.5px).

**Footer (border-top 1px `--border`, padding 10px):**
- **Context usage card**: bg `--surface`, 1px `--border`, 10px radius, padding 10/11. Header row: "Context" (12px/500, `--text-2`) + "31% used" (11.5px, `--text-3`). A 5px progress bar (track `--surface-4`, fill gradient accent→violet, width = pct). Sub-row: "in **48.1k**   out **9.7k**" (11px, values `--text-2` 600, tabular-nums).
- **Settings** row (ghost item, gear icon). **Click opens the Settings menu** (see Interactions).

### 3. Top bar (main column, 52px)
Flex row, 1px bottom border `--border`, items gap 8px:
- **Sidebar toggle** icon button (hamburger) — collapses/expands sidebar.
- **Chat title**: "Build C# desktop AutoCode app" (14.5px / 600) + muted "· edited 2h ago" (12.5px, `--text-faint`).
- Flex spacer.
- **Project-root chip**: folder icon + monospace path "…\automax\autocode" (12px, `--mono-font`), bg `--surface-2`, 1px `--border`, 8px radius. Tooltip = full path. (In the real app this is the chosen project root; clicking should open the folder picker — equivalent to the current "Choose" button.)
- **Theme toggle** icon button: moon icon in light mode / sun icon in dark mode. Toggles app theme. *(This deliberately lives on the header bar.)*
- **Workspace** toggle icon button (panel icon) — opens side panel to Workspace tab; `.on` state (bg `--surface-4`) when that tab is open.
- **Run** toggle icon button (terminal icon) — opens side panel to Run tab; shows a 7px amber badge dot (top-right) when an approval is pending and the panel is closed.
- **Session menu** icon button (horizontal dots).

Icon buttons: 34×34, 9px radius, color `--text-2`; hover bg `--hover` + `--text`; `.on` bg `--surface-4`.

### 4. Conversation (scroll area)
Centered column, **max-width 760px**, padding 26/28, vertical gap 18px between blocks. Block types:

- **"Worked for …" group** — collapsible. A ghost button row: chevron (rotates 90° open) + a small accent "bolt/spark" icon + label ("Worked for 12s" / "Worked for 4m 1s"), 13px `--text-3`. When open, renders **sub-steps** in a list indented with a 1.5px left rule `--border`: each step = green check icon + monospace tool name (`grep`, `read_file`, `edit_file`, `run_shell`…) + a plain-text detail (12.5px `--text-2`).
- **Assistant message** — plain block, 14.5px / line-height 1.62, color `--text`, paragraphs 12px gap. Contains rich inline elements:
  - **Inline code chips** (`<code>`): `--mono-font`, .86em, bg `--code-bg`, 1px `--border`, 6px radius, padding .12/.42em, `white-space:nowrap` (e.g. `21864`, `.NET Runtime`, `SetBrush`, `dotnet build`, `AutoCode Studio`).
  - **File-reference links**: accent color, weight 500, a small code-glyph icon + text like "MainWindow.xaml.cs (line 578)". Hover underline. (Clicking should open that file/line in the Workspace/preview.)
  - **Path block**: a full-width monospace box, bg `--surface-2`, 1px `--border`, 8px radius, padding 9/12 (e.g. `%LOCALAPPDATA%\autocode-gui\crash.log`).
- **User message** — right-aligned bubble: bg `--user-bubble`, 16px radius, padding 11/15, max-width 76%, 14px / 1.55.
- **Diff card** ("Edited N files") — 1px `--border`, 12px radius, bg `--surface`:
  - Header (padding 12/14): a 30×30 rounded icon tile (bg `--surface-3`) + title "Edited 2 files" (13.5px/600) + counts line `+42 −20` (mono 12px; adds green `--green`, dels red `--red`). Right side: **Undo** (ghost btn, undo icon) and **Review** (ghost btn → opens Run panel).
  - File rows (border-top `--border`, each 9/14, mono 12.5px): file icon + path (ellipsis) + per-file `+41 −12`. Hover bg `--surface-2`.
    - `AutoCode.Desktop/App.xaml.cs` → +41 −12
    - `AutoCode.Desktop/MainWindow.xaml.cs` → +1 −8
- **Reactions row** — four 30×30 ghost icon buttons: copy, thumbs-up, thumbs-down, share (color `--text-faint`, hover `--hover`).
- **Working indicator** — when a request is in flight, a row with a spinning accent spinner + "Working…".
- (Optional) **Notice banner** style exists for warnings: bg `--amber-bg`, 1px `--amber-line`, used e.g. for "Current working directory missing".

### 5. Composer (bottom of main column)
Centered, max-width 760px. Rounded container (16px radius, 1px `--border-strong`, bg `--surface`, soft shadow). Focus-within: border `--accent-line` + 3px `--accent-soft` ring.
- **Textarea**: transparent, auto-grows to max 160px, 14.5px / 1.5, placeholder "Ask for follow-up changes" (`--text-faint`). Enter submits, Shift+Enter newline.
- **Bottom bar** (gap 7px):
  - `+` attach icon button (32×32).
  - **Mode pill** — icon + label + chevron, 32px tall, 9px radius. Color-coded by mode (this is the agent safety mode; clicking opens the Mode menu):
    - `default` → "Default", shield-check icon, neutral (bg `--surface-2`).
    - `autocode` → "Full access", bolt icon, amber (text/border/bg amber tokens).
    - `planning` → "Plan only", plan icon, accent-tinted.
    - `admin` → "Admin", crown icon, red-tinted.
  - **Provider·model pill** — cube icon + "xai · grok-code-fast-1" + chevron. Opens the Model menu.
  - Flex spacer.
  - **Mic** icon button.
  - **Send** button — 34px accent-filled circle, up-arrow; disabled (bg `--surface-4`) when empty. While working it becomes a **Stop** button (dark fill, stop glyph).

### 6. Side panel (right, slide-over, 372px)
Background `--surface-2`, left border 1px `--border`. Width animates 0 ↔ 372px (~0.24s). Header (padding 9/10, bottom border): a segmented **tab control** (Workspace | Run) inside a `--surface-3` pill (active tab = bg `--surface` + small shadow); Run tab shows a 6px amber badge when an approval is pending. A close (×) icon button on the right.

**Workspace tab** (`sp-body`, padding 14):
- "SESSION" label + a monospace meta block (12px, keys in `--text-faint`):
  - `id  20260602-215440-51bc36`
  - `model  xai/grok-code-fast-1`
  - `root  …\automax\autocode`
  - *(Note: mode is intentionally NOT shown here — it lives only on the composer pill, to avoid duplication.)*
- "FILES" label + a **file tree** (monospace 12.5px). Rows: indent = depth × 16px + 6px, folder icon (color `--accent`) or file icon, name. Modified files show a trailing amber "M". Hover bg `--hover`. The tree mirrors the workspace shown in the current app (`.claude/`, `.github/workflows/`, `AutoCode.Desktop/`, `AutoCode.Engine/` with `Agent/`, `Tools/`, `Llm/`, `README.md`, `AutoCodeGui.sln`, etc.).

**Run tab:**
- **Pending-approval card** (when an approval is awaiting and mode requires it) — bg `--amber-bg`, 1px `--amber-line`, 12px radius:
  - Head: alert icon + "Pending approval" (13px/600).
  - Tool line (mono 12px): **`edit_file`** · `AutoCode.Desktop/App.xaml.cs · line 42`.
  - **Preview box** (bg `--surface`, 1px `--border`, mono 12px, max-height 190px, scroll): a diff with context/added/deleted lines — added lines green (`--green`), deleted red (`--red`), context `--text-3`.
  - **Revision textarea**: "Optional revision guidance…".
  - **Actions** (right-aligned): **Decline** (danger ghost), **Revise** (ghost), **Accept** (accent primary).
- **Resolved states** (after a decision, or auto by mode) — a single status line: Approved (green check), Auto-approved (bolt, for `autocode`/`admin`), Declined (red ×), Revision requested (undo), Blocked — read-only (plan) mode (shield).
- **Tool timeline** — "TOOL TIMELINE" label + stacked cards (1px `--border`, 10px radius, bg `--surface`, padding 10/12):
  - Top row: a status pill (18px circle) — **done** (green check, bg `--green-bg`), **running** (accent spinner, bg `--accent-soft`), **error** (red ×, bg `--red-bg`) — + monospace tool name + flex spacer + duration (11.5px `--text-faint`, tabular-nums).
  - Summary line (mono 12px `--text-2`). Examples used: `read_file · App.xaml.cs · 1–60` (0.1s), `grep "SetBrush" → 3 matches` (0.3s), `edit_file MainWindow.xaml.cs +1 −8` (0.2s), `run_shell dotnet build → Build succeeded` (11.4s), `run_shell dotnet test → Passed 5/5` (6.2s).
- Empty state: "No tools run yet." centered, `--text-faint`.

### 7. Menus (popovers)
Floating card: bg `--surface`, 1px `--border-strong`, 11px radius, big soft shadow, padding 5px, min-width ~196px. Items: 8/10 padding, 8px radius, 13px, hover `--hover`; icon `--text-3`; selected item uses accent color + trailing check. Section labels = 11px uppercase `--text-faint`. 1px `--border` separators.

- **Mode menu** (from mode pill, opens upward): label "Mode" + the four modes, each with icon, label, and a muted sub-description:
  - Default — "Edits & shell require approval"
  - Full access — "Auto-approve file edits & shell"
  - Plan only — "Read-only — no mutations"
  - Admin — "Unrestricted, incl. system ops"
- **Model menu** (from provider·model pill): label "Provider" + the four providers (anthropic / openai / xai / openrouter), then a separator, then label "Model · {provider}" + that provider's models. Selecting a provider resets to its first model. Provider→models map used:
  - anthropic: `claude-sonnet-4.5`, `claude-opus-4.1`, `claude-haiku-4`
  - openai: `gpt-5.2`, `gpt-5.2-mini`, `o4`
  - xai: `grok-code-fast-1`, `grok-4`, `grok-4-mini`
  - openrouter: `auto`, `qwen3-coder`, `deepseek-v3.2`
- **Settings menu** (from the Settings row, opens upward): **Bring your own keys** (key icon) → BYOK dialog; **Proxy access** (link icon) → Proxy dialog; separator; **Dark/Light mode** toggle; **About AutoCode Studio** → About dialog.

### 8. Dialogs (modal)
Scrim: `rgba(28,26,22,.34)` light / `rgba(0,0,0,.55)` dark, centered. Card: bg `--surface`, 1px `--border-strong`, 16px radius, big shadow. Header (18/18/14, bottom border): title (16px/600) + subtitle (12.5px `--text-3`) + close ×. Body padding 18. Footer (14/18, top border, bg `--surface-2`): right-aligned buttons.

- **BYOK ("Bring your own keys")** — width 500. Subtitle: "Environment variables take precedence. Saved keys are written to ~/.autocode-gui/config.json." Five fields, each = label + monospace env-var hint + password input (mono, 9px radius, bg `--surface-2`, focus accent ring):
  - Anthropic `ANTHROPIC_API_KEY` (ph `sk-ant-…`)
  - OpenAI `OPENAI_API_KEY` (ph `sk-…`)
  - xAI `XAI_API_KEY` (ph `xai-…`)
  - OpenRouter `OPENROUTER_API_KEY` (ph `sk-or-…`)
  - Brave Search `BRAVE_API_KEY` (ph `BSA…`)
  - Footer: Cancel / **Save keys** (primary). *(Real wiring: read/write the same config the engine already uses; env vars take precedence. A production release should move these to OS keyring.)*
- **Proxy access** — width 500. Subtitle about routing through a configurable proxy, falling back to `AUTOCODE_GUI_PROXY_*` env vars. Fields: **Proxy URL** (`AUTOCODE_GUI_PROXY_URL`, ph `https://your-proxy.example.com`) and **Proxy token** (`AUTOCODE_GUI_PROXY_TOKEN`, password). Note: "Requests route to `{proxyBaseUrl}/v1/{provider}` — e.g. `/v1/anthropic/messages`." Footer: Cancel / Save.
- **About** — width 420. Title "AutoCode Studio", subtitle "Automax agentic code shell", a short description, and a meta block (version 0.4.0, engine AutoCode.Engine, runtime .NET 8 · WPF). Footer: Close.

---

## Interactions & Behavior
- **Sidebar collapse**: hamburger toggles sidebar width 0 ↔ 262px (animate ~0.22s).
- **Project groups**: click a project row to expand/collapse its sessions (chevron rotates). "autocode gui" starts expanded.
- **Session select**: clicking a session marks it active (accent dot, `--surface-4` bg) and loads its transcript.
- **Theme toggle** (header + Settings menu): swaps light/dark resource dictionaries at runtime. Persist the choice.
- **Side panel**: Workspace/Run header buttons open the panel to that tab; tabs switch; × closes. Run badge appears when an approval is pending and the panel is closed.
- **Mode menu**: changes the agent safety mode. **Mode affects approvals**: in `default`/`planning` a mutating tool shows the pending-approval card (planning actually *blocks* mutations → "Blocked" state); in `autocode`/`admin` mutating tools are auto-approved (→ "Auto-approved" state, no card). Mutating tools = `edit_file`, `write_file`, `create_directory`, `delete_path`, `run_shell` (per `AgentLoop.GateFor`).
- **Model menu**: selecting a provider resets model to that provider's first; selecting a model closes the menu.
- **Approval actions**: Accept → resolves to "Approved" + appends an `edit_file` entry to the tool timeline; Decline → "Declined"; Revise → "Revision requested" (and would feed the revision text back to the agent).
- **Composer send**: Enter (no shift) submits; appends a user bubble, sets status "working" (spinner + a running tool-timeline entry), then resolves to an assistant reply and marks the tool done. Send button becomes Stop while working.
- **"Worked for …" groups**: click to expand/collapse sub-steps. The most recent one defaults to open.
- **Diff card Review / file-ref links**: open the relevant file/diff (Workspace/Run). 
- All transitions are short (~0.16–0.24s, ease). Respect reduced-motion.

## State Management
State needed (maps cleanly onto a WPF view-model with `INotifyPropertyChanged` + the existing engine event stream):
- `sidebarCollapsed: bool`
- `panelOpen: bool`, `panelTab: "workspace" | "run"`
- `mode: "default" | "autocode" | "planning" | "admin"` (drives the safety pill + approval gating)
- `provider`, `model`
- `activeSessionId`, plus the project→sessions list (from the sessions store)
- `theme: "light" | "dark"` (persisted)
- `messages` / transcript (from engine `AgentEvent` stream: message + tool-call/tool-result events)
- `timeline` (tool calls with status done/running/error + duration + summary)
- `approval` (current `ToolApprovalRequest`: tool name, target, preview) + its decision/derived state
- `status: "ready" | "working"`
- `usage` (input/output token counts)
- open menu / open modal (transient UI)
Tooltips, durations, and token counts come from the engine; the prototype hardcodes sample values.

## Design Tokens

### Colors — Light
| Token | Value | Use |
|---|---|---|
| `--titlebar` | `#efeeec` | title bar bg |
| `--titlebar-text` | `#45433f` | title bar text |
| `--surface` | `#ffffff` | cards, main bg |
| `--surface-2` | `#faf9f7` | sidebar, panels, inputs |
| `--surface-3` | `#f3f1ee` | hover tiles, tab track |
| `--surface-4` | `#ece9e4` | active rows, disabled |
| `--hover` | `rgba(34,32,28,.045)` | ghost hover |
| `--hover-strong` | `rgba(34,32,28,.075)` | win-btn hover |
| `--border` | `#e7e4df` | hairlines |
| `--border-strong` | `#d8d4ce` | button/input borders |
| `--text` | `#232120` | primary text |
| `--text-2` | `#56534e` | secondary |
| `--text-3` | `#8a867f` | tertiary |
| `--text-faint` | `#aaa59d` | labels, timestamps |
| `--user-bubble` | `#f1efec` | user message bubble |
| `--code-bg` | `#f1efeb` | inline code chip bg |
| `--code-text` | `#3a3733` | inline code text |
| `--accent` | `#2f6fe0` | links, primary, focus (themeable) |
| `--green` / `--green-bg` | `#1a7f47` / `#e7f4ec` | diff adds, done |
| `--red` / `--red-bg` | `#c4453a` / `#fbecea` | diff dels, error, close |
| `--amber` / `--amber-bg` / `--amber-line` | `#b06a14` / `#fdf2e2` / `#f0cf9a` | approvals, Full-access mode |

### Colors — Dark
| Token | Value |
|---|---|
| `--titlebar` | `#26241f` |
| `--titlebar-text` | `#cdc8be` |
| `--surface` | `#1c1b19` |
| `--surface-2` | `#201f1c` |
| `--surface-3` | `#262420` |
| `--surface-4` | `#2d2b26` |
| `--hover` | `rgba(255,252,245,.05)` |
| `--hover-strong` | `rgba(255,252,245,.09)` |
| `--border` | `#322f2a` |
| `--border-strong` | `#3d3933` |
| `--text` | `#ece8e0` |
| `--text-2` | `#b5b0a6` |
| `--text-3` | `#837f76` |
| `--text-faint` | `#635f58` |
| `--user-bubble` | `#2a2823` |
| `--code-bg` | `#2a2823` |
| `--code-text` | `#d6d1c7` |
| `--green-bg` | `#16271c` · `--red-bg` `#2c1916` · `--amber-bg` `#2c2113` · `--amber-line` `#5a431f` |

Accent stays `#2f6fe0` across themes (themeable). Curated accent options in the prototype: `#2f6fe0` (blue), `#6d54e0` (violet), `#1f8a5b` (green), `#d97757` (terracotta).

### Typography
- **UI font**: prototype uses *Geist* → use **Segoe UI Variable / Segoe UI** natively. Base 14px.
  - Sizes: title-bar 12.5 · sidebar items 13.5 · session/title 13 · chat-title 14.5/600 · assistant body 14.5 (lh 1.62) · bubble 14 · labels 11 (uppercase, +.04em, 600) · small/timestamps 11.5–12 · modal title 16/600.
- **Monospace**: prototype uses *Geist Mono* → use **Cascadia Code / Cascadia Mono / Consolas** natively. Used for code chips (.86em), file tree, tool names/summaries, path blocks, diff previews, key inputs/env hints. Tabular-nums for durations and token counts.

### Spacing / Radius / Shadow
- Sidebar 262px · side panel 372px · title bar 38px · top bar 52px · conversation/composer max-width 760px.
- Radii: window 14 · cards/diff/composer-container 12–16 · buttons/inputs/pills 8–10 · code chips 6 · status pills 50%.
- Icon buttons 34×34 (9px radius); pills 32px tall; send button 34px circle.
- Shadows: window = `0 30px 80px -20px rgba(40,38,34,.45), 0 8px 24px -12px rgba(40,38,34,.30)`; menus = `0 16px 40px -10px rgba(0,0,0,.28)`; modals = `0 30px 70px -18px rgba(0,0,0,.4)`. Focus ring = 3px `--accent-soft`.
- Density variants exist (compact/regular/comfy) scaling vertical padding ×0.82/1/1.16 and base font 13/14/15px — optional to port.

## Icons
All icons are simple 20×20 stroke icons (1.7 stroke, round caps, currentColor) defined inline in `icons.jsx`. Names used: menu, plus, search, settings(gear), chevron-right/down, folder, file, code, run/terminal, panel, x, mic, arrow-up, copy, thumb-up/down, share, shield-check, bolt, plan, crown, check, alert, spinner, dots, undo, diff, min, max, sun, moon, key, link, cube, stop. In WPF, reproduce with `Path`/`Geometry` resources or a vector icon set (e.g. Fluent System Icons / Segoe Fluent Icons) — match the simple stroke look. The app icon (`Assets/automax-dark.ico/.png`) is reused for the title bar logo chip (or keep the gradient bolt chip from the design).

## Assets
- App icon: `AutoCode.Desktop/Assets/automax-dark.ico` / `automax-dark.png` (existing).
- No raster imagery in the design — everything is type, color, and inline vector icons. No external image assets to import.

## Screenshots
High-fidelity captures of the key states are in `screenshots/` (1320×840, light unless noted):
- `01-default-light-run-panel.png` — default light theme, conversation + Run panel with a pending approval.
- `02-workspace-panel.png` — Workspace tab (session meta + file tree).
- `03-dark-mode.png` — dark theme (showing the Workspace file tree).
- `04-mode-menu.png` — Mode menu (Default / Full access / Plan only / Admin) open from the composer pill.
- `05-model-menu.png` — Provider + Model menu open.
- `06-settings-menu.png` — bottom-left Settings popup (BYOK / Proxy / theme / About).
- `07-byok-dialog.png` — Bring-your-own-keys dialog (five env-backed key fields).
- `08-proxy-dialog.png` — Proxy access dialog (URL + token).
- `09-full-access-auto-approved.png` — `autocode` mode: mutating tools auto-approved (no card), amber Full-access pill, full tool timeline.
- `10-sidebar-collapsed.png` — sidebar collapsed to maximize conversation width.

## Files (in this bundle)
- `AutoCode Studio.html` — entry point; load order + fonts.
- `styles.css` — **the authoritative source for all colors, sizing, spacing, and states** (CSS custom properties for both themes at top).
- `icons.jsx` — the full inline icon set.
- `data.jsx` — sample data (projects/sessions, modes, providers/models, file tree, tool timeline).
- `conversation.jsx` — transcript blocks (worked-for groups, diff card, reactions, composer).
- `components.jsx` — shell (title bar, sidebar, side panel, approval card, menu, modal).
- `app.jsx` — composition, state, menus, modals, theming.

Open `AutoCode Studio.html` in a browser to interact with the reference prototype. For exact values, read `styles.css`.

## Reference: existing codebase
- Redesign target: `AutoCode.Desktop/MainWindow.xaml` (+ `.cs`), `AutoCode.Desktop/App.xaml` (+ `.cs`).
- Unchanged backend to wire into: `AutoCode.Engine/Agent/*` (AgentLoop, AgentEvents, modes, approvals), `AutoCode.Engine/Tools/*` (read_file, edit_file, write_file, run_shell, grep, glob, find_symbol, ask_user, web_fetch, web_search), `AutoCode.Engine/Llm/*`, `AutoCode.Engine/Auth/*`.
- Modes, providers, proxy routing, and BYOK env-var names are documented in the repo `README.md` and match this design.
