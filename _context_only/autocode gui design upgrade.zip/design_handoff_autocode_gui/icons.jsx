// icons.jsx — single Icon component, stroke-based, currentColor.
const ICON_PATHS = {
  menu: '<line x1="3" y1="6" x2="17" y2="6"/><line x1="3" y1="10" x2="17" y2="10"/><line x1="3" y1="14" x2="17" y2="14"/>',
  plus: '<line x1="10" y1="4" x2="10" y2="16"/><line x1="4" y1="10" x2="16" y2="10"/>',
  search: '<circle cx="9" cy="9" r="5.5"/><line x1="13.5" y1="13.5" x2="17" y2="17"/>',
  settings: '<circle cx="10" cy="10" r="2.6"/><path d="M10 2.2v2.4M10 15.4v2.4M2.2 10h2.4M15.4 10h2.4M4.5 4.5l1.7 1.7M13.8 13.8l1.7 1.7M15.5 4.5l-1.7 1.7M6.2 13.8l-1.7 1.7"/>',
  chevR: '<polyline points="7 4 13 10 7 16"/>',
  chevD: '<polyline points="4 7 10 13 16 7"/>',
  folder: '<path d="M2.5 5.5a1 1 0 0 1 1-1H8l1.5 1.5h7a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1h-13a1 1 0 0 1-1-1z"/>',
  file: '<path d="M5 2.5h6l4 4V17a.5.5 0 0 1-.5.5h-9A.5.5 0 0 1 5 17z"/><polyline points="11 2.5 11 6.5 15 6.5"/>',
  code: '<polyline points="7 6 3.5 10 7 14"/><polyline points="13 6 16.5 10 13 14"/>',
  run: '<rect x="2.5" y="3.5" width="15" height="13" rx="2"/><polyline points="6 8 8.5 10 6 12"/><line x1="10.5" y1="12" x2="13.5" y2="12"/>',
  panel: '<rect x="2.5" y="3.5" width="15" height="13" rx="2"/><line x1="12.5" y1="3.5" x2="12.5" y2="16.5"/>',
  x: '<line x1="5" y1="5" x2="15" y2="15"/><line x1="15" y1="5" x2="5" y2="15"/>',
  mic: '<rect x="7.5" y="2.5" width="5" height="9" rx="2.5"/><path d="M4.5 9.5a5.5 5.5 0 0 0 11 0"/><line x1="10" y1="15" x2="10" y2="17.5"/>',
  arrowUp: '<line x1="10" y1="15.5" x2="10" y2="4.5"/><polyline points="5 9.5 10 4.5 15 9.5"/>',
  copy: '<rect x="6.5" y="6.5" width="9" height="9" rx="1.6"/><path d="M3.5 11.5v-7a1 1 0 0 1 1-1h7"/>',
  thumbUp: '<path d="M6 9.5l2.5-5.5a1.6 1.6 0 0 1 1.6 1.9L9.5 8.5h4a1.4 1.4 0 0 1 1.4 1.7l-1 4.2a1.6 1.6 0 0 1-1.5 1.1H6z"/><line x1="6" y1="9.5" x2="6" y2="15.5"/><rect x="2.5" y="9.5" width="3.5" height="6" rx="1"/>',
  thumbDn: '<path d="M14 10.5l-2.5 5.5a1.6 1.6 0 0 1-1.6-1.9l.6-2.6h-4a1.4 1.4 0 0 1-1.4-1.7l1-4.2A1.6 1.6 0 0 1 7.6 4.5H14z"/><line x1="14" y1="10.5" x2="14" y2="4.5"/><rect x="14" y="4.5" width="3.5" height="6" rx="1"/>',
  share: '<circle cx="6" cy="10" r="2"/><circle cx="14" cy="5" r="2"/><circle cx="14" cy="15" r="2"/><line x1="7.7" y1="9" x2="12.3" y2="6"/><line x1="7.7" y1="11" x2="12.3" y2="14"/>',
  shield: '<path d="M10 2.5l6 2.2v4.3c0 3.6-2.5 6.9-6 8-3.5-1.1-6-4.4-6-8V4.7z"/>',
  shieldCheck: '<path d="M10 2.5l6 2.2v4.3c0 3.6-2.5 6.9-6 8-3.5-1.1-6-4.4-6-8V4.7z"/><polyline points="7.3 9.7 9.2 11.6 12.8 7.8"/>',
  bolt: '<polygon points="11 2.5 4.5 11 9 11 8.5 17.5 15 9 10.5 9"/>',
  plan: '<rect x="3.5" y="3" width="13" height="14" rx="2"/><line x1="6.5" y1="7" x2="13.5" y2="7"/><line x1="6.5" y1="10" x2="13.5" y2="10"/><line x1="6.5" y1="13" x2="11" y2="13"/>',
  crown: '<path d="M3 14l-1-7 4 3 4-6 4 6 4-3-1 7z"/><line x1="3" y1="16.5" x2="17" y2="16.5"/>',
  check: '<polyline points="4 10.5 8 14.5 16 5.5"/>',
  alert: '<path d="M10 3l8 14H2z"/><line x1="10" y1="8" x2="10" y2="12.5"/><circle cx="10" cy="15" r=".6" fill="currentColor" stroke="none"/>',
  spinner: '<path d="M10 2.5a7.5 7.5 0 1 1-7.5 7.5" />',
  dots: '<circle cx="5" cy="10" r="1.3" fill="currentColor" stroke="none"/><circle cx="10" cy="10" r="1.3" fill="currentColor" stroke="none"/><circle cx="15" cy="10" r="1.3" fill="currentColor" stroke="none"/>',
  sliders: '<line x1="3" y1="6" x2="17" y2="6"/><line x1="3" y1="14" x2="17" y2="14"/><circle cx="13" cy="6" r="2.2" fill="var(--surface)"/><circle cx="7" cy="14" r="2.2" fill="var(--surface)"/>',
  undo: '<polyline points="7 5 3.5 8.5 7 12"/><path d="M3.5 8.5h8a4.5 4.5 0 0 1 0 9H7"/>',
  diff: '<line x1="10" y1="3" x2="10" y2="8"/><line x1="7.5" y1="5.5" x2="12.5" y2="5.5"/><circle cx="10" cy="14.5" r="0"/><line x1="7.5" y1="14.5" x2="12.5" y2="14.5"/><rect x="3" y="3" width="14" height="14" rx="2.5" opacity="0"/>',
  min: '<line x1="4" y1="9" x2="14" y2="9"/>',
  max: '<rect x="4" y="4" width="10" height="10" rx="1"/>',
  globe: '<circle cx="10" cy="10" r="7"/><ellipse cx="10" cy="10" rx="3" ry="7"/><line x1="3" y1="10" x2="17" y2="10"/>',
  terminal: '<rect x="2.5" y="3.5" width="15" height="13" rx="2"/><polyline points="6 8 8.5 10 6 12"/><line x1="10.5" y1="12" x2="13.5" y2="12"/>',
  cube: '<path d="M10 2.5l7 4v7l-7 4-7-4v-7z"/><polyline points="3 6.5 10 10.5 17 6.5"/><line x1="10" y1="10.5" x2="10" y2="17.5"/>',
  stop: '<rect x="5" y="5" width="10" height="10" rx="2"/>',
  sun: '<circle cx="10" cy="10" r="3.5"/><path d="M10 1.8v2.2M10 16v2.2M1.8 10h2.2M16 10h2.2M4.2 4.2l1.5 1.5M14.3 14.3l1.5 1.5M15.8 4.2l-1.5 1.5M5.7 14.3l-1.5 1.5"/>',
  moon: '<path d="M16.2 11.4A6.6 6.6 0 1 1 8.6 3.8a5.1 5.1 0 0 0 7.6 7.6z"/>',
  key: '<circle cx="6.5" cy="13.5" r="3"/><line x1="8.7" y1="11.3" x2="16" y2="4"/><line x1="13" y1="7" x2="15.4" y2="9.4"/>',
  link: '<path d="M8.2 11.8a3 3 0 0 1 0-4.2l1.8-1.8a3 3 0 0 1 4.2 4.2L13 11.4"/><path d="M11.8 8.2a3 3 0 0 1 0 4.2L10 14.2a3 3 0 0 1-4.2-4.2L7 8.6"/>',
};

function Icon({ name, size = 18, stroke = 1.7, className = "", style }) {
  return (
    <svg className={"ic " + className} width={size} height={size} viewBox="0 0 20 20"
      fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      style={style} dangerouslySetInnerHTML={{ __html: ICON_PATHS[name] || "" }} />
  );
}

window.Icon = Icon;
